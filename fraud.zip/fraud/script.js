function scrollToInfo() {
  const section = document.getElementById('info');
  section.scrollIntoView({ behavior: 'smooth' });
}
